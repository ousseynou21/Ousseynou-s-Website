console.log("Hello World");

var name="Ousseynou";

function getMilk(bottles) {
console.log("leaveHouse");
console.log("moveRight");
console.log("moveRight");
console.log("moveUp");
console.log("moveUp");
console.log("moveUp");
console.log("moveUp");
console.log("moveRight");
console.log("moveRight");
console.log("buy" + "bottles of milk");
console.log("moveLeft");
console.log("moveLeft");
console.log("moveDown");
console.log("moveDown");
console.log("moveDown");
console.log("moveDown");
console.log("moveLeft");
console.log("moveLeft");
console.log("enterHouse");

return money % 1.5;
}

return calcChange(money, 1.5);

getMilk(12);

var numberOfbottles = Math.floor(money/ 1.5);

var numberOfbottles = Math.floor(startingMoney / costPerBottle);

return numberOfbottles;

function calcChange(startingAmount, costPerBottle) {
var change = startingAmount % costPerBottle;
return change;


console.log("buy" + numberOfbottles + "bottles of milk");

getMilk(5); //$1.5 $/1.5 = 3 bottles

console.log("buy" + calcBottles(money, 1.5) + "bottles of milk");

//Create your function below this line.

function bmiCalculator(weight, height) {
    var bmi = weight / (height * height);
    return bmi;
}
/* If my weight is 65Kg and my height is 1.8m, I should be able to call your function like this:

var bmi = bmiCalculator(65, 1.8);

bmi should equal around 20 in this case.

*/
function bmiCalculator(weight, height) {

  var bmi = weight / Math.pow(height, 2);
  return bmi;

}


function bmiCalculator(weight, height) {

  var bmi = weight / Math.pow(height, 2);
  return Math.round(bmi);








}
