console.log("Hello World");

var name="Ousseynou";

function getMilk(bottles) {
console.log("leaveHouse");
console.log("moveRight");
console.log("moveRight");
console.log("moveUp");
console.log("moveUp");
console.log("moveUp");
console.log("moveUp");
console.log("moveRight");
console.log("moveRight");
console.log("buy" + "bottles of milk");
console.log("moveLeft");
console.log("moveLeft");
console.log("moveDown");
console.log("moveDown");
console.log("moveDown");
console.log("moveDown");
console.log("moveLeft");
console.log("moveLeft");
console.log("enterHouse");

return money % 1.5;
}

return calcChange(money, 1.5);

getMilk(12);

var numberOfbottles = Math.floor(money/ 1.5);

var numberOfbottles = Math.floor(startingMoney / costPerBottle);

return numberOfbottles;

function calcChange(startingAmount, costPerBottle) {
var change = startingAmount % costPerBottle;
return change;


console.log("buy" + numberOfbottles + "bottles of milk");

getMilk(5); //$1.5 $/1.5 = 3 bottles

console.log("buy" + calcBottles(money, 1.5) + "bottles of milk");

//Create your function below this line.

function bmiCalculator(weight, height) {
    var bmi = weight / (height * height);
    return bmi;
}
/* If my weight is 65Kg and my height is 1.8m, I should be able to call your function like this:
var bmi = bmiCalculator(65, 1.8);
bmi should equal around 20 in this case.
*/
function bmiCalculator(weight, height) {

  var bmi = weight / Math.pow(height, 2);
  return bmi;

}


function bmiCalculator(weight, height) {

  var bmi = weight / Math.pow(height, 2);
  return Math.round(bmi);

  prompt("What is your name");
prompt("What is your name");

var loverscore = Math.floor(lovescore) + 1;
console.log(loveScore);
alert("Your love score is" + loverscore "%");

if (track === "clear {goStraight()};
else {turnRIght()};
if (track === "clear") {
goStraighht();
}
else {
  turmRight();
}
if (loveScore > 70) {
  alert("Your loeve score" + "%" "You love eachother like Kanye loves Kanye.");
} else {
  alert("Your love score is " + "%");
}
if (a === b) {
  console.log("Yes");
} else {
  console.log("No");
}
if (lovescore > 30 && loveScore <= 70) {
  alert("Your love score is" + loveScore + "%");
}
var myEgg = eggs[1];
var guestList = ["Angela" "Jack" "TOby" "Lara" "Jason"]
Angela
Jack
TOby
Lara
Jason
var a = "Angela"
var b = 123;
item.push
item.pop
function FizzBuzz() {
  output.push(count);
  count++;
  console.log(output);
}
if (count % 3 === 0 66 count % 5 === 0) {
  output.push("FizzBuz")
}
var i =1
while(i<2) {
  console.log(i);
  I++
}
While(count <= 1000)
ar numberOfBottles = 99
while (numberOfBottles >= 0) {
    var bottleWord = "bottle";
    if (numberOfBottles === 1) {
        bottleWord = "bottles";
    }
    console.log(numberOfBottles + " " + bottleWord + " of beer on the wall");
    console.log(numberOfBottles + " " + bottleWord + " of beer,");
    console.log("Take one down, pass it around,");
	numberOfBottles--;
    console.log(numberOfBottles + " " + bottleWord + " of beer on the wall.");
}
for (i=0; i<2; i++) {
  //Do something
}
for (numberOfBottles >= 0) {
    var bottleWord = "bottle";
    if (numberOfBottles === 1) {
        bottleWord = "bottles";
    }
    console.log(numberOfBottles + " " + bottleWord + " of beer on the wall");
    console.log(numberOfBottles + " " + bottleWord + " of beer,");
    console.log("Take one down, pass it around,");
	numberOfBottles--;
    console.log(numberOfBottles + " " + bottleWord + " of beer on the wall.");
}
for (vr count =1; count <101; count++)
}

document.getElementsByTagName("li")

document.querySelector("h1").classList.add("huge");
