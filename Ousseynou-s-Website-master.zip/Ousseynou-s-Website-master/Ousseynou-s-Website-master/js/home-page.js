console.log("Hello World");

var name="Ousseynou";

function getMilk(bottles) {
console.log("leaveHouse");
console.log("moveRight");
console.log("moveRight");
console.log("moveUp");
console.log("moveUp");
console.log("moveUp");
console.log("moveUp");
console.log("moveRight");
console.log("moveRight");
console.log("buy" + "bottles of milk");
console.log("moveLeft");
console.log("moveLeft");
console.log("moveDown");
console.log("moveDown");
console.log("moveDown");
console.log("moveDown");
console.log("moveLeft");
console.log("moveLeft");
console.log("enterHouse");

return money % 1.5;
}

return calcChange(money, 1.5);

getMilk(12);

var numberOfbottles = Math.floor(money/ 1.5);

var numberOfbottles = Math.floor(startingMoney / costPerBottle);

return numberOfbottles;

function calcChange(startingAmount, costPerBottle) {
var change = startingAmount % costPerBottle;
return change;


}

console.log("buy" + numberOfbottles + "bottles of milk");

getMilk(5); //$1.5 $/1.5 = 3 bottles

console.log("buy" + calcBottles(money, 1.5) + "bottles of milk");












}
